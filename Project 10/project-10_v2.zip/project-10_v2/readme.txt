1. Поправил в дашборде подписи (Subtitle) 
https://public.tableau.com/views/Book1_16423277373030/Dashboard1?:language=en-US&publish=yes&:display_count=n&:origin=viz_share_link
2. Обновил презентацию, добавил больше информации